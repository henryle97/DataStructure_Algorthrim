C++ implementation of a Hash-Table as a dictionary. Currently, program can display all words, and allow users to search for a specific word. Word/Definition matching will be implemented soon. 
=====================
